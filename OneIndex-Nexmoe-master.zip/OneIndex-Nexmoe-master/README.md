# OneIndex-Nexmoe

- 魔改过Nexmoe主题的OneIndex

- 结合了[oneindex](https://github.com/donwa/oneindex)和[OneIndex-theme](https://github.com/Zisbusy/OneIndex-theme)

### 修改
1. `view\nexmoe`中的`layout.php`
  - 第15行直接修改为自己的QQ或者引用图片的地址
  - 第18行`acidwits.xyz`改为自己的博客地址
2. `view/nexmoe/theme`中的`style.css`
  - 第114行是背景图片，可以自行更改
### 安装
- 按照OneIndex的说明进行安装即可